var Greeter = function () {
  this.say = function (name) {
    return "Hello, " + name + "!";
  };
};