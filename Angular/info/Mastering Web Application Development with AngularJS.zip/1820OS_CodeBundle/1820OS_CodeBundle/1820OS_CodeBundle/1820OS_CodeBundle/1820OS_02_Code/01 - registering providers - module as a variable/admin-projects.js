var adminProjects = angular.module('admin-projects', []);

adminProjects.controller('ProjectsListCtrl', function($scope) {
  //controller's code go here
});

adminProjects.controller('ProjectsEditCtrl', function($scope) {
  //controller's code go here
});