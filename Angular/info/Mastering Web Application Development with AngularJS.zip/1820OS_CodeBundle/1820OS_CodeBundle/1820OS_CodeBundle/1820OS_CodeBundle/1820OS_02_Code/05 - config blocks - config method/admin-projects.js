angular.module('admin-projects', [])
  .config(function() {
    //configuration block 1
  })
  .config(function() {
    //configuration block 2
  });
