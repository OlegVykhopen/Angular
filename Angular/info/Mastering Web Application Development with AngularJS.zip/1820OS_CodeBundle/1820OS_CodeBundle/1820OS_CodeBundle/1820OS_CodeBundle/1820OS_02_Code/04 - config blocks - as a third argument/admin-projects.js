angular.module('admin-projects', [], function() {
  //configuration logic goes here
});
