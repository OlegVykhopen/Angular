angular.module('admin-projects', [])

  .controller('ProjectsListCtrl', function($scope) {
  //controller's code go here
  })

  .controller('ProjectsEditCtrl', function($scope) {
  //controller's code go here
  });