angular.module('admin-projects', []);

angular.module('admin-projects').controller('ProjectsListCtrl', function($scope) {
  //controller's code go here
});

angular.module('admin-projects').controller('ProjectsEditCtrl', function($scope) {
  //controller's code go here
});