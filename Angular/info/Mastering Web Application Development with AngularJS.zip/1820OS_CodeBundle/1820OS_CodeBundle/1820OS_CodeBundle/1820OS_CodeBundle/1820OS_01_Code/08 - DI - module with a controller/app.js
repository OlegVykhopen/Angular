angular.module('hello', []).controller('HelloCtrl', function($scope){
  $scope.name = 'World';
});