angular.module('upTimeApp', []).run(function($rootScope) {
    $rootScope.appStarted = new Date();
});


